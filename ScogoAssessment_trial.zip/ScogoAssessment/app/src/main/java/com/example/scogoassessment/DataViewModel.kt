package com.example.scogoassessment

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class DataViewModel: ViewModel() {

    private val _DataList = mutableStateListOf<DemoData>()
    var errorMessage: String by mutableStateOf("")
    val DataList: List<DemoData>
        get() = _DataList

    fun getDataLList(){
        viewModelScope.launch {
            val datarequest=DataRequest.getInstance()
            try{
                _DataList.clear()
                _DataList.addAll(datarequest.getdatas())
            }catch (e: Exception) {
                errorMessage = e.message.toString()
            }
        }
    }
}

