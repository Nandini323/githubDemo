package com.example.scogoassessment.ui.theme

import android.os.Bundle
import android.os.PersistableBundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.scogoassessment.DataVisibleView
import java.time.format.TextStyle

class SecondActivity  : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent{
            MaterialTheme {
            TextView()
            }
        }
    }


    @Composable
    fun TextView() {
        /*Column(modifier = Modifier.padding(200.dp)){
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(0.dp, 0.dp, 200.dp, 0.dp)

            ) {
                Text(
                    "adddd",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }*/
        Card {


            Column(modifier = Modifier.padding(16.dp)) {
                var name = intent.getStringExtra("title")
                var type = intent.getStringExtra("type")
                var symbol = intent.getStringExtra("symbol")
                var id = intent.getStringExtra("id")
                Text(
                    text = "Coin Name: $name \n"
                )
                Text(
                    text = "Coin Type: $type \n"
                )
                Text(
                    text = "Coin Symbol:  $symbol \n"
                )
                Text(
                    text = "Coin id:  $id \n"
                )

            }
        }
    }
}